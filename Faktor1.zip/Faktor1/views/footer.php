<div class="clearfix"></div>

    <footer class="site-footer">
        <div class="footer-inner bg-white">
            <div class="row">
                <div class="col-sm-6">
                    Copyright &copy; Faktor CPC
                </div>
                <div class="col-sm-6 text-right">
                    Designed by <a href="https://colorlib.com">Faktor CPC</a>
                </div>
            </div>
        </div>
    </footer>

</div><!-- /#right-panel -->

<!-- Right Panel -->

<!-- Scripts -->
<script src="js/jquery/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="js/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="js/jquery-match-height/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="js/jquery/dist/jquery.js"></script>
<script src="js/sweetalert.min.js"></script>
<script src="js/Aseguradora.js"></script>
<script src="js/Paciente.js"></script>
<script src="js/btnDeleteAs.js"></script>
<script src="js/btnDeleteP.js"></script>
<script src="js/medAseguradora.js"></script>
<script src="js/operaciones.js"></script>



    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>
    <script src="assets/js/init/fullcalendar-init.js"></script>
</body>
</html>