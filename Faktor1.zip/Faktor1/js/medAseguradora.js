 var num= 1;

$('#clonform').click(function() {
	if(num==1){
  var clone = $('#form0').clone('#form0').attr("id","form"+num);
  var button='<button type="button" class="btn btn-danger" id="btnRemover" onclick="Remo(1)">Remover</button>'
  $('#alta_MedicoAs').append(clone);
  $('.form-actions').append(button);
  num=num+1;
} else {
	var clone = $('#form0').clone('#form0').attr("id","form"+num);
  	$('#alta_MedicoAs').append(clone);
  	var butt=$('#btnRemover').attr("onclick","Remo("+num+")");
  	$('.form-actions').append(butt);
  num=num+1;
}

});

function Remo(valor){
$('#form'+valor).remove();

}

$('#altaMS').click(function(){

  var form = $('#alta_MedicoAs').serialize();

  $.ajax({
    method: 'POST',
    url: 'controller/altamedAs.php',
    data: form,
    beforeSend: function(){
      $('#load').show();
    },
    success: function(res){
      $('#load').hide();

      if(res == 'error_1'){
        swal('Error', 'Campos obligatorios, por favor llena el nombre aseguradora, direccion y link', 'warning');
      }else if(res == 'enviado'){
        swal('Error', 'Las claves deben ser iguales, por favor intentalo de nuevo', 'error');
      }else if(res == 'error_3'){
        swal('Error', 'El correo que ingresaste ya se encuentra registrado', 'error');
      }else if(res == 'error_4'){
        swal('Error', 'Por favor ingresa un correo valido', 'warning');
      }else{
        window.location.href = res ;
      }


    }
  });

});
