# normalize.min.css

> Provide a compressed version of normalize.css

Source code :[https://github.com/necolas/normalize.css](https://github.com/necolas/normalize.css)