<?php 

  $siniestro  = $_POST['siniestro'];
  $descripcion = $_POST['descripcion'];
  $fecha  = $_POST['fecha'];
  $rol  = $_POST['rol'];
  $honorario  = $_POST['honorario'];
 
 
    if(empty($siniestro) || empty($descripcion) || empty($honorario))
  {

    echo 'error_1'; // Un campo esta vacio y es obligatorio

  }else{
    require_once('../model/procedimiento.php');
    
    $altacaso = new procedimiento();

    $altacaso -> addCaso($siniestro, $descripcion, $rol,$honorario);
  }
?>