<?php 
$arr = var_dump($_POST); 
for($i = 0; $i <= count($arr['selectUs'])-1;$i++){

    $medico = $arr['selectUs'][$i];
    $nAseguradora= $arr['selectAs'][$i];
    $usuario = $arr['userAseguradora'][$i];
    $contraseña = $arr['passwordAseguradora'][$i];

  	if(empty($medico) || empty($nAseguradora) || empty($usuario)||empty($contraseña))
  {

    echo 'error_1'; // Un campo esta vacio y es obligatorio

  }else{
  	require_once('../model/medicoAseg.php');
  	
  	$altamedAseguradora = new medicoAseg();

  	$altamedAseguradora -> addmedAseguradora($medico,$nAseguradora, $usuario, $contraseña);
  }
}
?>